<?php
        echo "<center>Atenção usuário, você não fez o LOGIN no sistema!<br><br>";
        echo "<a href=\"".$controle."index.html\">Voltar</a></center>";

        ?>